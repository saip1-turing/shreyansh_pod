from .interface_1 import ALL_TOOLS_INTERFACE_1
from .interface_2 import ALL_TOOLS_INTERFACE_2
from .interface_3 import ALL_TOOLS_INTERFACE_3
from .interface_4 import ALL_TOOLS_INTERFACE_4
from .interface_5 import ALL_TOOLS_INTERFACE_5

ALL_TOOLS = [
    ALL_TOOLS_INTERFACE_1,
    ALL_TOOLS_INTERFACE_2,
    ALL_TOOLS_INTERFACE_3,
    ALL_TOOLS_INTERFACE_4,
    ALL_TOOLS_INTERFACE_5,
]
